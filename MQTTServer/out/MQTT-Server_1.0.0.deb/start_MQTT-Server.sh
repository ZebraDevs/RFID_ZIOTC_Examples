#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=MQTT-Server_1.0.0
export BUILD_DATE=2026-07-14T14:00:55+01:00
cd /apps/MQTT-Server_1.0.0
case $( uname -m ) in 
  aarch64*)
    export WORKING_FILE=MQTT-Server-64.elf
    ./MQTT-Server-64.elf & ;;
  *)
    export WORKING_FILE=MQTT-Server.elf
    ./MQTT-Server.elf & ;;
esac
