#!/bin/bash
case $( uname -m ) in 
  aarch64*)
    kill -2 `ps -ef 2> /dev/null | grep MQTT-Server-64.elf | awk '{ print $2 }'` ;;
  *)
    kill -2 `ps -ef 2> /dev/null | grep MQTT-Server.elf | awk '{ print $2 }'` ;;
esac
