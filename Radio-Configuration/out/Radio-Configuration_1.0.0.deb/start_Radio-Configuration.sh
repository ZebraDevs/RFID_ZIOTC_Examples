#!/bin/bash
cd /apps
VERSION=1.0.0
python Radio-Configuration.py &
