#!/bin/bash
case $( uname -m ) in 
  aarch64*)
    kill -2 `ps -ef 2> /dev/null | grep RFID-Monitor-64.elf | awk '{ print $2 }'` ;;
  *)
    kill -2 `ps -ef 2> /dev/null | grep RFID-Monitor.elf | awk '{ print $2 }'` ;;
esac
