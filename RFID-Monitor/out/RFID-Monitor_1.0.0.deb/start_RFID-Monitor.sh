#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=RFID-Monitor_1.0.0
export BUILD_DATE=2026-07-14T11:45:50+01:00
cd /apps/RFID-Monitor_1.0.0
case $( uname -m ) in 
  aarch64*)
    export WORKING_FILE=RFID-Monitor-64.elf
    ./RFID-Monitor-64.elf & ;;
  *)
    export WORKING_FILE=RFID-Monitor.elf
    ./RFID-Monitor.elf & ;;
esac
