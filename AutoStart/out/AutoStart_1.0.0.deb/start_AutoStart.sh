#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=AutoStart_1.0.0
export WORKING_FILE=AutoStart.py
export BUILD_DATE=2025-04-17T09:36:05+01:00
cd /apps/AutoStart_1.0.0
python3 AutoStart.py &
