#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=GPI-Message_1.0.0
export WORKING_FILE=GPI-Message.py
export BUILD_DATE=2024-07-02T10:45:39+01:00
cd /apps/GPI-Message_1.0.0
python3 GPI-Message.py &
