#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=ATR-Viewer_1.0.0
export WORKING_FILE=ATR-Viewer.elf
export BUILD_DATE=2025-09-30T13:44:04+01:00
cd /apps/ATR-Viewer_1.0.0
./ATR-Viewer.elf &
