#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=ATR-Viewer_1.0.0
export BUILD_DATE=2026-11-19T09:53:58Z
cd /apps/ATR-Viewer_1.0.0
export WORKING_FILE=ATR-Viewer.elf
./ATR-Viewer.elf &
