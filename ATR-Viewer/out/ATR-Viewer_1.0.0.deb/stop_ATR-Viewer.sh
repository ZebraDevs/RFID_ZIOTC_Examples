#!/bin/bash
kill -2 `ps -ef 2> /dev/null | grep ATR-Viewer.elf | awk '{ print $2 }'`
