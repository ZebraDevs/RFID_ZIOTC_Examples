#!/bin/bash
kill -2 `ps -ef 2> /dev/null | grep python | grep GRAI-96-Decoder.py | awk '{ print $2 }'`
