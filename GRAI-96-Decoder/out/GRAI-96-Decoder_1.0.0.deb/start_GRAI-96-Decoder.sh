#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=GRAI-96-Decoder_1.0.0
export WORKING_FILE=GRAI-96-Decoder.py
export BUILD_DATE=2025-04-04T09:22:47+01:00
cd /apps/GRAI-96-Decoder_1.0.0
python3 GRAI-96-Decoder.py &
