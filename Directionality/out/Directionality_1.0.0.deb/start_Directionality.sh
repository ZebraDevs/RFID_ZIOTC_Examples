#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=Directionality_1.0.0
export WORKING_FILE=Directionality.py
export BUILD_DATE=2024-07-02T10:45:09+01:00
cd /apps/Directionality_1.0.0
python3 Directionality.py &
