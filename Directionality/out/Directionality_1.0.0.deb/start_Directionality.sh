#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=Directionality_1.0.0
export WORKING_FILE=Directionality.py
cd /apps/Directionality_1.0.0
python Directionality.py &
