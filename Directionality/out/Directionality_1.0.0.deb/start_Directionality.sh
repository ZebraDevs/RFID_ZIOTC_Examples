#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=Directionality_1.0.0
export WORKING_FILE=Directionality.py
export BUILD_DATE=2025-04-17T10:14:15+01:00
cd /apps/Directionality_1.0.0
python3 Directionality.py &
