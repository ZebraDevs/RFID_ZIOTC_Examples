#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=Keyout_1.0.0
export WORKING_FILE=Keyout.py
export BUILD_DATE=2024-08-02T15:47:29+01:00
cd /apps/Keyout_1.0.0
python3 Keyout.py &
