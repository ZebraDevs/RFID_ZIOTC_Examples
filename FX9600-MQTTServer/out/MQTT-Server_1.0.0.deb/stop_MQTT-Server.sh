#!/bin/bash
kill -2 `ps -ef 2> /dev/null | grep MQTT-Server.elf | awk '{ print $2 }'`
