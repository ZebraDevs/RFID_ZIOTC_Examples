#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=MQTT-Server_1.0.0
export WORKING_FILE=MQTT-Server.elf
export BUILD_DATE=2025-10-01T10:19:19+01:00
cd /apps/MQTT-Server_1.0.0
./MQTT-Server.elf &
