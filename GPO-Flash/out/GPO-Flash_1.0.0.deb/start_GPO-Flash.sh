#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=GPO-Flash_1.0.0
export WORKING_FILE=GPO-Flash.py
export BUILD_DATE=2024-07-02T10:46:11+01:00
cd /apps/GPO-Flash_1.0.0
python3 GPO-Flash.py &
