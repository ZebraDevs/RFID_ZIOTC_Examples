#!/bin/bash
kill -2 `ps -ef 2> /dev/null | grep python | grep GPO-Flash.py | awk '{ print $2 }'`
